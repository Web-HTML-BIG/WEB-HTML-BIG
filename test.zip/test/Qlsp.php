<?php
include 'db.php';
$stmt = $pdo->query("SELECT sp.*, loaisp.TENLOAI FROM sp JOIN loaisp ON sp.IDLSP = loaisp.IDLSP");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?> 

<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <title>Quản lý sản phẩm</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/Qlsp.css" type="text/css">
</head>
<body>


    <!-- Shop Section -->
    <section class="shop spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center" style="margin-bottom: 30px;">
                    <a href="add-product.php"><button class="add-product">&#43; Thêm sản phẩm</button></a>
                </div>
                <div class="col-lg-12">
                    <div class="row">
                        <?php foreach ($products as $product): ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="product__item">
                                    <div class="product__item__pic set-bg" data-setbg="<?php echo $product['URL']; ?>"></div>
                                    <div class="product__item__text">
                                        <h6><a href="#"><?php echo $product['TEN']; ?></a></h6>
                                        <div class="product__price"><?php echo $product['GIABANKM']; ?> đ <span><?php echo $product['GIABAN']; ?> đ</span></div>
                                        <div class="product__actions">
                                            <a href="edit-product.php?id=<?php echo $product['IDSP']; ?>"><button class="edit-product">&#9998; Sửa</button></a>
                                            <a href="delete-product.php?id=<?php echo $product['IDSP']; ?>" onclick="return confirmDelete(<?php echo $product['IDSP']; ?>)"><button class="delete-product">&#8722; Xóa</button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section (copied from the template) -->
    <footer class="footer">
        <!-- ... (unchanged from the provided HTML) -->
    </footer>

    <!-- JS Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script>
        function confirmDelete(id) {
            <?php
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM ctdh WHERE IDSP = ?");
            foreach ($products as $product) {
                $stmt->execute([$product['IDSP']]);
                $sold = $stmt->fetchColumn();
                echo "if (id == {$product['IDSP']} && $sold > 0) { return confirm('Sản phẩm đã được bán. Bạn có muốn ẩn nó không?'); }";
            }            ?>
            return confirm('Bạn có chắc muốn xóa sản phẩm này không?');
        }
    </script>
</body>
</html>