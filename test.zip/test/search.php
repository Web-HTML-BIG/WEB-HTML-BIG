<?php
// Connect to database
$conn = new mysqli("localhost", "root", "", "web_db");

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Get search parameters
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
$brands = isset($_GET['brand']) ? $_GET['brand'] : [];
$min_price = isset($_GET['min_price']) ? (int)$_GET['min_price'] : 1000000;
$max_price = isset($_GET['max_price']) ? (int)$_GET['max_price'] : 5000000;

// Build SQL query
$sql = "SELECT * FROM sp WHERE 1=1";
if (!empty($keyword)) {
    $sql .= " AND TEN LIKE '%" . $conn->real_escape_string($keyword) . "%'";
}
if (!empty($brands) && is_array($brands)) {
    $brands_str = "'" . implode("','", array_map([$conn, 'real_escape_string'], $brands)) . "'";
    $sql .= " AND IDLSP IN (SELECT IDLSP FROM loaisp WHERE TENLOAI IN ($brands_str))";
}
$sql .= " AND REPLACE(GIABAN, '.', '') BETWEEN $min_price AND $max_price";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="col-lg-4 col-md-6">';
        echo '<div class="product__item">';
        echo '<div class="product__item__pic set-bg" data-setbg="' . htmlspecialchars($row["URL"]) . '">';
        echo '<ul class="product__hover">';
        echo '<li><a href="' . htmlspecialchars($row["URL"]) . '" class="image-popup"><span class="arrow_expand"></span></a></li>';
        echo '<li><a href="#"><span class="icon_bag_alt"></span></a></li>';
        echo '</ul>';
        echo '</div>';
        echo '<div class="product__item__text">';
        echo '<h6><a href="./chitietsanpham_logged_in.html">' . htmlspecialchars($row["TEN"]) . '</a></h6>';
        echo '<div class="rating">';
        echo '<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>';
        echo '</div>';
        echo '<div class="product__price">' . number_format(str_replace('.', '', $row["GIABAN"]), 0) . ' đ <span>' . number_format(str_replace('.', '', $row["GIABANKM"]), 0) . ' đ</span></div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo '<p style="text-align:center; width:100%;">Không tìm thấy sản phẩm nào.</p>';
}

$conn->close();
?>