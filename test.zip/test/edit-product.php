<?php
include 'db.php';

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM sp WHERE IDSP = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idlsp = $_POST['idlsp'];
    $ten = $_POST['ten'];
    $mota = $_POST['mota'];
    $giaban = $_POST['giaban'];
    $giabankm = $_POST['giabankm'];

    $url = $product['URL'];
    if (!empty($_FILES["image"]["name"])) {
        $target_dir = "img/shop/";
        $image_name = basename($_FILES["image"]["name"]);
        $url = $target_dir . $image_name;
        move_uploaded_file($_FILES["image"]["tmp_name"], $url);
    }

    $stmt = $pdo->prepare("UPDATE sp SET IDLSP = ?, URL = ?, TEN = ?, MOTA = ?, GIABAN = ?, GIABANKM = ? WHERE IDSP = ?");
    $stmt->execute([$idlsp, $url, $ten, $mota, $giaban, $giabankm, $id]);

    header("Location: Qlsp.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM loaisp");
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <title>Sửa sản phẩm</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
    <section class="shop spad">
        <div class="container">
            <h2>Sửa sản phẩm</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Phân loại</label>
                    <select name="idlsp" class="form-control" required>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['IDLSP']; ?>" <?php if ($category['IDLSP'] == $product['IDLSP']) echo 'selected'; ?>><?php echo $category['TENLOAI']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tên sản phẩm</label>
                    <input type="text" name="ten" class="form-control" value="<?php echo $product['TEN']; ?>" required>
                </div>
                <div class="form-group">
                    <label>Mô tả</label>
                    <textarea name="mota" class="form-control" required><?php echo $product['MOTA']; ?></textarea>
                </div>
                <div class="form-group">
                    <label>Giá bán</label>
                    <input type="text" name="giaban" class="form-control" value="<?php echo $product['GIABAN']; ?>" required>
                </div>
                <div class="form-group">
                    <label>Giá bán khuyến mãi</label>
                    <input type="text" name="giabankm" class="form-control" value="<?php echo $product['GIABANKM']; ?>" required>
                </div>
                <div class="form-group">
                    <label>Hình ảnh hiện tại</label>
                    <img src="<?php echo $product['URL']; ?>" style="max-width: 200px;" />
                    <label>Thay đổi hình ảnh</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*" onchange="previewImage(event)">
                    <img id="image-preview" style="max-width: 200px; margin-top: 10px;" />
                </div>
                <button type="submit" class="btn btn-primary">Lưu</button>
                <a href="products.php" class="btn btn-secondary">Hủy</a>
            </form>
        </div>
    </section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script>
        function previewImage(event) {
            const reader = new FileReader();
            reader.onload = function() {
                const output = document.getElementById('image-preview');
                output.src = reader.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
</body>
</html>