<?php
include 'db.php'; // This defines $pdo using PDO

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idlsp = $_POST['idlsp'];
    $ten = $_POST['ten'];
    $mota = $_POST['mota'];
    $giaban = $_POST['giaban'];
    $giabankm = $_POST['giabankm'];

    // Handle image upload
    $target_dir = "img/shop/";
    $image_name = basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $image_name;
    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        die("Error: Failed to upload image.");
    }

    // Generate new IDSP (e.g., SP001, SP002, etc.)
    $stmt = $pdo->query("SELECT MAX(IDSP) as max_id FROM sp");
    $max_id = $stmt->fetch(PDO::FETCH_ASSOC)['max_id'];
    if ($max_id) {
        $new_id_num = (int)substr($max_id, 2) + 1; // Extract number from SPxxx and increment
    } else {
        $new_id_num = 1; // If no records exist, start with 1
    }
    $idsp = "SP" . sprintf("%03d", $new_id_num); // Format as SP001, SP002, etc.

    // Prepare and execute the insert query using PDO
    $stmt = $pdo->prepare("INSERT INTO sp (IDSP, IDLSP, URL, TEN, MOTA, GIABAN, GIABANKM) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$idsp, $idlsp, $target_file, $ten, $mota, $giaban, $giabankm]); // Updated query with IDSP

    header("Location: Qlsp.php");
    exit;
}

// Fetch categories using PDO
$result = $pdo->query("SELECT * FROM loaisp");
$categories = $result->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <title>Thêm sản phẩm</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
    <section class="shop spad">
        <div class="container">
            <h2>Thêm sản phẩm</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Phân loại</label>
                    <select name="idlsp" class="form-control" required>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['IDLSP']; ?>"><?php echo $category['TENLOAI']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tên sản phẩm</label>
                    <input type="text" name="ten" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Mô tả</label>
                    <textarea name="mota" class="form-control" required></textarea>
                </div>
                <div class="form-group">
                    <label>Giá bán</label>
                    <input type="text" name="giaban" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Giá bán khuyến mãi</label>
                    <input type="text" name="giabankm" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Hình ảnh</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*" onchange="previewImage(event)" required>
                    <img id="image-preview" style="max-width: 200px; margin-top: 10px;" />
                </div>
                <button type="submit" class="btn btn-primary">Thêm</button>
                <a href="Qlsp.php" class="btn btn-secondary">Hủy</a>
            </form>
        </div>
    </section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script>
        function previewImage(event) {
            const reader = new FileReader();
            reader.onload = function() {
                const output = document.getElementById('image-preview');
                output.src = reader.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
</body>
</html>